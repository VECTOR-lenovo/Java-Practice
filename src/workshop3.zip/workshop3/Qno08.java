package workshop3;

public class Qno08 {
    public static void main(String[] args) {
        bankaccountQn03 account = new bankaccountQn03();
    }
}
